<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>DAHONG</title>
  <style>
    body {
      background: linear-gradient(135deg, #1a1a1a, #333);
      color: #fff;
      font-family: 'Arial', sans-serif;
      text-align: center;
      padding-top: 100px;
      margin: 0;
    }

    h1 {
      font-size: 60px;
      letter-spacing: 5px;
      animation: glow 2s ease-in-out infinite alternate;
    }

    @keyframes glow {
      from {
        text-shadow: 0 0 10px #ff0000, 0 0 20px #ff0000;
      }
      to {
        text-shadow: 0 0 20px #00ffcc, 0 0 30px #00ffcc;
      }
    }

    p {
      font-size: 20px;
      margin-top: 30px;
    }

    button {
      margin-top: 40px;
      padding: 15px 30px;
      background: #00ccff;
      border: none;
      color: white;
      font-size: 18px;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    button:hover {
      background: #0099cc;
    }
  </style>
</head>
<body>
  <h1>DAHONG</h1>
  <p>Selamat datang di halaman pribadi DAHONG.</p>
  <button onclick="alert('Halo DAHONG!')">Klik Saya</button>
</body>
</html>
